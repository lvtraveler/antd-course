import {
    ClampToEdgeWrapping,
    DataTexture,
    FloatType,
    HalfFloatType,
    LinearFilter,
    Mesh,
    NearestFilter,
    PlaneBufferGeometry,
    RGBAFormat,
    RepeatWrapping,
    ShaderMaterial,
    UniformsUtils,
    Vector2,
    Vector3,
    WebGLRenderTarget,
    BufferGeometry,
    BufferAttribute
} from "./three.module.js";
import {WaterShaders} from "./WaterShader.js";

var Water = function (renderer,camera,scene,options) {

    //用于触发参数更改的标志
    this.changed = true;
    this.initial = true;

    this.watercamera = camera.clone(); //camera.clone();
    this.renderer = renderer;
    this.renderer.clearColor( 0xffffff );

    this.scene = scene.clone();

    //将可选参数指定为变量和对象的属性
    function optionalParameter(value, defaultValue){
        return value != undefined ? value : defaultValue;
    }
    options = options || {};
    this.watervertices = options.WATER_VERTICE;
    this.waterindexs = options.WATER_INDEX;
    this.wateruvs = options.WATER_UV;
    this.clearColor = optionalParameter(options.CLEAR_COLOR, [ 1.0, 1.0, 1.0, 0.0 ]);
    this.oceanColor = optionalParameter(options.WATER_COLOR, new Vector3( 0.004, 0.016, 0.047 ));
    this.skyColor = optionalParameter( options.SKY_COLOR, new Vector3( 3.2, 9.6, 12.8 ) );
    this.geometryResolution = optionalParameter( options.GEOMETRY_RESOLUTION, 32 );  //几何体精细度
    this.geometrySize = optionalParameter( options.GEOMETRY_SIZE, 2500 );   //几何尺寸
    this.resolution = optionalParameter( options.RESOLUTION, 64 );
    this.windX = optionalParameter( options.INITIAL_WIND[ 0 ], 10.0 );
    this.windY = optionalParameter( options.INITIAL_WIND[ 1 ], 10.0 );
    this.size = optionalParameter( options.INITIAL_SIZE, 250.0 );
    this.choppiness = 0.5 ;  //波率

    this.matrixNeedsUpdate = false;

    //用于纹理参数设置以及渲染的细节参数
    var LinearClampParams = {
        minFilter: LinearFilter,
        maxFilter: LinearFilter,
        wrapS: ClampToEdgeWrapping,
        wrapT: ClampToEdgeWrapping,
        format: RGBAFormat,
        stencilBuffer: false,  //模板缓冲区
        depthBuffer: false,  //深度缓冲区
        premultiplyAlpha: false,
        type: FloatType
    }

    var NearestClampParams = {
        minFilter: NearestFilter,
        magFilter: NearestFilter,
        wrapS: ClampToEdgeWrapping,
        wrapT: ClampToEdgeWrapping,
        format: RGBAFormat,
        stencilBuffer: false,
        depthBuffer: false,
        premultiplyAlpha: false,
        type: FloatType
    };

    var NearestRepeatParams = {
        minFilter: NearestFilter,
        magFilter: NearestFilter,
        wrapS: RepeatWrapping,
        wrapT: RepeatWrapping,
        format: RGBAFormat,
        stencilBuffer: false,
        depthBuffer: false,
        premultiplyAlpha: false,
        type: FloatType
    };

    //定义了8个缓冲区，用于保存渲染后的像素
    //WebGLRenderTarget 实现离屏渲染功能，渲染的图像结果保存到该对象，保存到GPU自定义帧缓冲区中，通过.texture获取渲染的结果
    this.initialSpectrumFramebuffer = new WebGLRenderTarget(this.resolution,this.resolution,NearestRepeatParams); //初始频谱帧缓冲器
    this.spectrumFramebuffer = new WebGLRenderTarget( this.resolution, this.resolution, NearestClampParams );  //光谱（频谱）帧缓冲器
    this.pingPhaseFramebuffer = new WebGLRenderTarget( this.resolution, this.resolution, NearestClampParams );  //脉冲相位帧缓冲器
    this.pongPhaseFramebuffer = new WebGLRenderTarget( this.resolution, this.resolution, NearestClampParams );
    this.pingTransformFramebuffer = new WebGLRenderTarget( this.resolution, this.resolution, NearestClampParams );//ping转换帧缓冲器
    this.pongTransformFramebuffer = new WebGLRenderTarget( this.resolution, this.resolution, NearestClampParams ); //pong转换帧缓冲器
    this.displacementMapFramebuffer = new WebGLRenderTarget( this.resolution, this.resolution, LinearClampParams );  //位移图帧缓冲器
    this.normalMapFramebuffer = new WebGLRenderTarget( this.resolution, this.resolution, LinearClampParams );  //法线贴图帧缓冲器



    //第一步:顶点着色器
    var fullscreenVertexShader = WaterShaders[ "water_sim_vertex" ];   //顶点着色器，用于设置以(0,0)为中心的2x2仿真平面

    //对于二维的FFT只需要横向变换后再纵向变换即可.
    //第二步：用于FFT的水平波顶点
    var waterHorizontalShader = WaterShaders[ "water_subtransform" ];     //用于细分网格的片段着色器(生成位移贴图)
    var waterHorizontalUniforms = UniformsUtils.clone( waterHorizontalShader.uniforms ); //获取该对象shader中定义的参数
    this.materialWaterHorizontal = new ShaderMaterial({
        uniforms: waterHorizontalUniforms,
        vertexShader: fullscreenVertexShader.vertexShader,
        fragmentShader: "#define HORIZONTAL \n"+ waterHorizontalShader.fragmentShader
    });
    this.materialWaterHorizontal.uniforms.u_transformSize = { value: this.resolution };
    this.materialWaterHorizontal.uniforms.u_subtransformSize = {value: null};
    this.materialWaterHorizontal.uniforms.u_input = { value: null };
    this.materialWaterHorizontal.depthTest = false;

    //用于FFT的垂直波顶点
    var waterVerticalShader = WaterShaders[ "water_subtransform" ];  //用于细分网格的片段着色器(生成位移贴图)
    var waterVerticalUniforms = UniformsUtils.clone( waterVerticalShader.uniforms );
    this.materialWaterVertical = new ShaderMaterial( {
        uniforms: waterVerticalUniforms,
        vertexShader: fullscreenVertexShader.vertexShader,
        fragmentShader: waterVerticalShader.fragmentShader
    } );
    this.materialWaterVertical.uniforms.u_transformSize = { value: this.resolution };
    this.materialWaterVertical.uniforms.u_subtransformSize = { value: null };
    this.materialWaterVertical.uniforms.u_input = { value: null };
    this.materialWaterVertical.depthTest = false;

    //第三步：用于生成高度图的初始频谱
    var initialSpectrumShader = WaterShaders[ "water_initial_spectrum"];
    var initialSpectrumUniforms = UniformsUtils.clone( initialSpectrumShader.uniforms );
    this.materialInitialSpectrum = new ShaderMaterial({
        uniforms: initialSpectrumUniforms,
        vertexShader: initialSpectrumShader.vertexShader,
        fragmentShader: initialSpectrumShader.fragmentShader
    });
    this.materialInitialSpectrum.uniforms.u_wind = { value : new Vector2() };
    this.materialInitialSpectrum.uniforms.u_resolution = { value : this.resolution};
    this.materialInitialSpectrum.depthTest = false;

    //第四步： 阶段（phase（相位）的复数形式）用于激活高度地图
    var phaseShader = WaterShaders[ "water_phase" ];
    var phaseUniforms = UniformsUtils.clone( phaseShader.uniforms );
    this.materialPhase = new ShaderMaterial({
        uniforms: phaseUniforms,
        vertexShader: fullscreenVertexShader.vertexShader,
        fragmentShader: phaseShader.fragmentShader
    });
    this.materialPhase.uniforms.u_resolution = { value: this.resolution };
    this.materialPhase.depthTest = false;

    // 第五步： 着色器用来更新频谱
    var spectrumShader = WaterShaders[ "water_spectrum" ];
    var spectrumUniforms = UniformsUtils.clone( spectrumShader.uniforms );
    this.materialSpectrum = new ShaderMaterial( {
        uniforms: spectrumUniforms,
        vertexShader: fullscreenVertexShader.vertexShader,
        fragmentShader: spectrumShader.fragmentShader
    } );
    this.materialSpectrum.uniforms.u_initialSpectrum = { value: null };
    this.materialSpectrum.uniforms.u_resolution = { value: this.resolution };
    this.materialSpectrum.depthTest = false;

    // 6 - Shader used to update spectrum normals
    var normalShader = WaterShaders[ "water_normals" ];
    var normalUniforms = UniformsUtils.clone( normalShader.uniforms );
    this.materialNormal = new ShaderMaterial( {
        uniforms: normalUniforms,
        vertexShader: fullscreenVertexShader.vertexShader,
        fragmentShader: normalShader.fragmentShader
    } );
    this.materialNormal.uniforms.u_displacementMap = { value: null };
    this.materialNormal.uniforms.u_resolution = { value: this.resolution };
    this.materialNormal.depthTest = false;

    var waterShader = WaterShaders[ "water_main" ];
    var waterUniforms = UniformsUtils.clone( waterShader.uniforms );
    this.materialWater = new ShaderMaterial( {
        uniforms: waterUniforms,
        vertexShader: waterShader.vertexShader,
        fragmentShader: waterShader.fragmentShader
    } );

    //this.materialWater.wireframe = true;
    this.materialWater.uniforms.u_geometrySize = { value: this.resolution };
    this.materialWater.uniforms.u_displacementMap = { value: this.displacementMapFramebuffer.texture };
    this.materialWater.uniforms.u_normalMap = { value: this.normalMapFramebuffer.texture };
    this.materialWater.uniforms.u_oceanColor = { value: this.oceanColor };
    this.materialWater.uniforms.u_skyColor = { value: this.skyColor };

    // Disable blending to prevent default premultiplied alpha values
    this.materialWaterHorizontal.blending = 0;
    this.materialWaterVertical.blending = 0;
    this.materialInitialSpectrum.blending = 0;
    this.materialPhase.blending = 0;
    this.materialSpectrum.blending = 0;
    this.materialNormal.blending = 0;
    this.materialWater.blending = 0;

    // Create the simulation plane
    this.screenQuad = new Mesh( new PlaneBufferGeometry( 2, 2) );
    this.scene.add( this.screenQuad );


    this.generateSeedPhaseTexture();

    this.generateMesh();

};

Water.prototype.generateMesh = function () {

    var geometry2 = new PlaneBufferGeometry( this.geometrySize, this.geometrySize, this.geometryResolution, this.geometryResolution );
    geometry2.rotateX( - Math.PI / 2 )
    this.WaterMesh2 = new Mesh( geometry2, this.materialWater );

    var geometry =  new BufferGeometry();
    var attribute = new BufferAttribute(this.watervertices, 3);  //3个为一组，表示一个顶点的下xyz坐标
    geometry.attributes.position = attribute;
    geometry.index = new BufferAttribute(new Uint16Array(this.waterindexs), 1);
    geometry.computeVertexNormals();

        geometry.attributes.uv = new BufferAttribute(new Float32Array(this.wateruvs), 2);
        this.WaterMesh = new Mesh( geometry, this.materialWater );



};

Water.prototype.render = function () {

    var currentRenderTarget = this.renderer.getRenderTarget();

    this.scene.overrideMaterial = null;

    if ( this.changed )
        this.renderInitialSpectrum();

    this.renderWavePhase();
    this.renderSpectrum();
    this.renderSpectrumFFT();
    this.renderNormalMap();
    this.scene.overrideMaterial = null;

    this.renderer.setRenderTarget( currentRenderTarget );

};

//初始化频谱数据 ，生成初始的纹理贴图
Water.prototype.generateSeedPhaseTexture = function () {

    // 设置子纹理
    this.pingPhase = true;
    var phaseArray = new window.Float32Array( this.resolution * this.resolution * 4 );   //创建缓冲区空间
    //随机的RGBA分量值
    for ( var i = 0; i < this.resolution; i ++ ) {

        for ( var j = 0; j < this.resolution; j ++ ) {

            phaseArray[ i * this.resolution * 4 + j * 4 ] = Math.random() * 2.0 * Math.PI;  //0<random<1
            phaseArray[ i * this.resolution * 4 + j * 4 + 1 ] = 0.0;
            phaseArray[ i * this.resolution * 4 + j * 4 + 2 ] = 0.0;
            phaseArray[ i * this.resolution * 4 + j * 4 + 3 ] = 0.0;

        }

    }
    //数据纹理对象(通过程序创建纹理贴图的每一个像素值）
    this.pingPhaseTexture = new DataTexture( phaseArray, this.resolution, this.resolution, RGBAFormat );  //resolution 为纹理的宽度和高度，格式采用RGBFormat用于解析这类型格式数据
    this.pingPhaseTexture.wrapS = ClampToEdgeWrapping;  //.wrapS定义了纹理如何水平包裹，并对应于UV映射中的U. .wrapT这定义了纹理垂直包裹的方式，与UV映射中的V相对应.
    this.pingPhaseTexture.wrapT = ClampToEdgeWrapping;
    this.pingPhaseTexture.type = FloatType;
};

Water.prototype.renderInitialSpectrum = function () {

    this.scene.overrideMaterial = this.materialInitialSpectrum;
    this.materialInitialSpectrum.uniforms.u_wind.value.set( this.windX, this.windY );
    this.materialInitialSpectrum.uniforms.u_size.value = this.size;

    this.renderer.setRenderTarget( this.initialSpectrumFramebuffer );   //将渲染的图像结果的RGBA像素数据保存到该自定义的帧缓冲区中
    this.renderer.clear();
    this.renderer.render( this.scene, this.watercamera );

};

Water.prototype.renderWavePhase = function () {

    this.scene.overrideMaterial = this.materialPhase;
    this.screenQuad.material = this.materialPhase;
    if ( this.initial ) {

        this.materialPhase.uniforms.u_phases.value = this.pingPhaseTexture;
        this.initial = false;
    } else {

        this.materialPhase.uniforms.u_phases.value = this.pingPhase ? this.pingPhaseFramebuffer.texture : this.pongPhaseFramebuffer.texture;

    }
    this.materialPhase.uniforms.u_deltaTime.value = this.deltaTime;
    this.materialPhase.uniforms.u_size.value = this.size;
    this.renderer.setRenderTarget( this.pingPhase ? this.pongPhaseFramebuffer : this.pingPhaseFramebuffer );
    this.renderer.render( this.scene, this.watercamera );
    this.pingPhase = ! this.pingPhase;

};

Water.prototype.renderSpectrum = function () {

    this.scene.overrideMaterial = this.materialSpectrum;
    this.materialSpectrum.uniforms.u_initialSpectrum.value = this.initialSpectrumFramebuffer.texture;
    this.materialSpectrum.uniforms.u_phases.value = this.pingPhase ? this.pingPhaseFramebuffer.texture : this.pongPhaseFramebuffer.texture;
    this.materialSpectrum.uniforms.u_choppiness.value = this.choppiness;
    this.materialSpectrum.uniforms.u_size.value = this.size;

    this.renderer.setRenderTarget( this.spectrumFramebuffer );
    this.renderer.render( this.scene, this.watercamera );

};

Water.prototype.renderSpectrumFFT = function () {


    var iterations = Math.log( this.resolution ) / Math.log( 2 ); // log2   //计算迭代次数

    //分别对纵向和横向进行FFT迭代

    this.scene.overrideMaterial = this.materialWaterHorizontal;

    for ( var i = 0; i < iterations; i ++ ) {

        if ( i === 0 ) {

            this.materialWaterHorizontal.uniforms.u_input.value = this.spectrumFramebuffer.texture;
            this.materialWaterHorizontal.uniforms.u_subtransformSize.value = Math.pow( 2, ( i % ( iterations ) ) + 1 );

            this.renderer.setRenderTarget( this.pingTransformFramebuffer );
            this.renderer.render( this.scene, this.watercamera );

        } else if ( i % 2 === 1){

            this.materialWaterHorizontal.uniforms.u_input.value = this.pingTransformFramebuffer.texture;
            this.materialWaterHorizontal.uniforms.u_subtransformSize.value = Math.pow( 2, ( i % ( iterations ) ) + 1 );

            this.renderer.setRenderTarget( this.pongTransformFramebuffer );
            this.renderer.render( this.scene, this.watercamera );

        } else {

            this.materialWaterHorizontal.uniforms.u_input.value = this.pongTransformFramebuffer.texture;
            this.materialWaterHorizontal.uniforms.u_subtransformSize.value = Math.pow( 2, ( i % ( iterations ) ) + 1 );

            this.renderer.setRenderTarget( this.pingTransformFramebuffer );
            this.renderer.render( this.scene, this.watercamera );

        }

    }
    this.scene.overrideMaterial = this.materialWaterVertical;
    for ( var i = iterations; i < iterations * 2; i ++ ) {

        if ( i === iterations * 2 - 1 ) {

            this.materialWaterVertical.uniforms.u_input.value = ( iterations % 2 === 0 ) ? this.pingTransformFramebuffer.texture : this.pongTransformFramebuffer.texture;
            this.materialWaterVertical.uniforms.u_subtransformSize.value = Math.pow( 2, ( i % ( iterations ) ) + 1 );

            this.renderer.setRenderTarget( this.displacementMapFramebuffer );
            this.renderer.render( this.scene, this.watercamera );

        } else if ( i % 2 === 1 ) {

            this.materialWaterVertical.uniforms.u_input.value = this.pingTransformFramebuffer.texture;
            this.materialWaterVertical.uniforms.u_subtransformSize.value = Math.pow( 2, ( i % ( iterations ) ) + 1 );

            this.renderer.setRenderTarget( this.pongTransformFramebuffer );
            this.renderer.render( this.scene, this.watercamera );

        } else {

            this.materialWaterVertical.uniforms.u_input.value = this.pongTransformFramebuffer.texture;
            this.materialWaterVertical.uniforms.u_subtransformSize.value = Math.pow( 2, ( i % ( iterations ) ) + 1 );

            this.renderer.setRenderTarget( this.pingTransformFramebuffer );
            this.renderer.render( this.scene, this.watercamera );

        }

    }

};

Water.prototype.renderNormalMap = function () {

    this.scene.overrideMaterial = this.materialNormal;
    if ( this.changed ) this.materialNormal.uniforms.u_size.value = this.size;
    this.materialNormal.uniforms.u_displacementMap.value = this.displacementMapFramebuffer.texture;

    this.renderer.setRenderTarget( this.normalMapFramebuffer );
    this.renderer.clear();
    this.renderer.render( this.scene, this.watercamera );

};

export { Water };
